
/**
 * easyloader - EasyUI for jQuery
 * 
 */


export function area(radius) {
  return Math.PI * radius * radius;
}

export function circumference(radius) {
  return 2 * Math.PI * radius;
}